/*************************************************************************
> File Name: BaseKinematics.h
> Function:  底盘运动学模型
> Auther :  Lv Chaoshun
> Mail:   lvchaoshun@outlook.com
> Completed Time: 2017.5.22
************************************************************************/

namespace savvy_controller
{
    class BaseKinematics
    {
        
    };
}