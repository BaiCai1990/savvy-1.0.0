/*************************************************************************
> File Name: SavvyOdometry.h
> Function:  机器人里程计信息处理
> Auther :  Lv Chaoshun
> Mail:   lvchaoshun@outlook.com
> Completed Time: 2017.5.22
************************************************************************/

#ifndef SAVVYODOMETRY_H_
#define SAVVYODOMETRY_H_

namespace savvy_controller
{
    class SavvyOdometry
    {
        
        
    };
}
